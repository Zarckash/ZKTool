$ErrorActionPreference = 'SilentlyContinue'

New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT | Out-Null

$BufferbloatStatus = Get-ItemPropertyValue -Path "HKCR:\Directory\Background\shell\ZKTool\shell\03BufferbloatFix" -Name "MUIVerb"
$Interface = Get-NetIPConfiguration | Select-Object -ExpandProperty InterfaceAlias

if ($BufferbloatStatus -eq "Bufferbloat Enable") {
    netsh int tcp set global autotuninglevel=disabled
    netsh int ipv4 set subinterface $Interface mtu=850 store=persistent
    Disable-NetAdapter -Name $Interface -Confirm:$False
    Enable-NetAdapter -Name $Interface -Confirm:$False
    Set-ItemProperty -Path "HKCR:\Directory\Background\shell\ZKTool\shell\03BufferbloatFix" -Name "MUIVerb" -Value "Bufferbloat Disable"
    Set-ItemProperty -Path "HKCR:\Directory\Background\shell\ZKTool\shell\03BufferbloatFix" -Name "Icon" -Value "inetcpl.cpl,21"
} else {
    netsh int tcp set global autotuninglevel=normal
    netsh int ipv4 set subinterface $Interface mtu=1500 store=persistent
    Disable-NetAdapter -Name $Interface -Confirm:$False
    Enable-NetAdapter -Name $Interface -Confirm:$False
    Set-ItemProperty -Path "HKCR:\Directory\Background\shell\ZKTool\shell\03BufferbloatFix" -Name "MUIVerb" -Value "Bufferbloat Enable"
    Set-ItemProperty -Path "HKCR:\Directory\Background\shell\ZKTool\shell\03BufferbloatFix" -Name "Icon" -Value "inetcpl.cpl,20"
}