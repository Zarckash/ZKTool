$ErrorActionPreference = 'SilentlyContinue'

New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT | Out-Null

$Rule = "BlockSteam"
$Interface =  Get-NetAdapter | Where-Object Status -eq "Up" | Select-Object -ExpandProperty "Name"

if (Get-NetFirewallRule -DisplayName $Rule) {

} else {
    New-NetFirewallRule -DisplayName $Rule -Direction Outbound -Action Block -Program "C:\Program Files (x86)\Steam\steam.exe" -Enabled False | Out-Null
}

$BlockStatus = Get-ItemPropertyValue -Path "HKCR:\Directory\Background\shell\ZKTool\shell\04SteamBlock" -Name "MUIVerb"

if ($BlockStatus -eq "Disable Steam") {
    Enable-NetFirewallRule -DisplayName $Rule
    Disable-NetAdapter -Name $Interface -Confirm:$False
    Enable-NetAdapter -Name $Interface -Confirm:$False
    Set-ItemProperty -Path "HKCR:\Directory\Background\shell\ZKTool\shell\04SteamBlock" -Name "MUIVerb" -Value "Enable Steam"
} else {
    Disable-NetFirewallRule -DisplayName $Rule
    Disable-NetAdapter -Name $Interface -Confirm:$False
    Enable-NetAdapter -Name $Interface -Confirm:$False
    Set-ItemProperty -Path "HKCR:\Directory\Background\shell\ZKTool\shell\04SteamBlock" -Name "MUIVerb" -Value "Disable Steam"
}